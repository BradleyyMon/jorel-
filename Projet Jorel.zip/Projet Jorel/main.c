#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <ctype.h>
#include <string.h>
#include <conio.h>

//MONDESTIN Claudyson
//JEAN Myderson
//JOSESH Christerlin
//AUGUSTAVE Roulopheny
//VALES Hertz
//MERIUS Berjany F. Joolson


//Declaration des prototypes

int genererNumeroProduit();
int testDoublonProd(char nom[30]);

int testNIF(char nif[11]);
int testNIFempdouble(char nif[11]);
int testNIFcldouble(char nif[11]);
int testNumTel(char numTel[9]);
int testNumTelempDouble(char champ[9]);
int testNumTelcliDouble(char champ[9]);

void Enregistrer_produit();
void Lister_produit();
void Rechercher_produit();
void Augmenter_caisse();
void Supprimer_produit();
void Gestion_des_produits();

void Gestion_des_ventes();
void Gestion_des_clients();
void Enregistrer_client();
void Lister_client();
void Rechercher_client();
void Modifier_client();
void Supprimer_client();

void Gestion_du_perso();
void Enregistrer_employe();
void Lister_employe();
void Rechercher_employe();
void Modifier_employe();
void Revoquer_employe();
void Augmentation_salaire();

void Effectuer_vente();
void Lister_vente();
void Rechercher_vente();
void Modifier_vente();
void Annuler_vente();

void MenuPrincipal();
int menuGestionProduits();
int menuGestionClients();
int menuGestionEmployes();
int menuGestionVentes();
void gotoxy(int x, int y);
int main();

//Structure produit
typedef struct produits{
    int numStock;
    char nom_produit[50];
    char categorie[20];
    int nb_caisse;
    double prix;
} Produit;
// Structure clients

typedef struct clients{
    char nif[11];
    char nom_client[50];
    char prenom_client[50];
    char adresse_client[100];
    char tel_client[9];
} Client;

// Structure employe
typedef struct employes{
    char nif_employe[11];
    char nom_employe[50];
    char prenom_employe[50];
    char adresse_employe[100];
    char tel_employe[9];
    double salaire;
} Employe;

// Structure de vente
typedef struct ventes{
    int numVente;
    int numProduit;
    char numClient[9];
    char nomCl[50];
    char nomPr[50];
    int quantite;
    double montantAchat;
} Vente;


Produit prod[5000];
Client cl[20000];
Employe emp[100];
Vente ventes[5000];


int nbre_Produits = 0;
int nbre_Clients = 0;
int nbre_Employes=0;
int nbre_Ventes = 0;




void gotoxy(int x, int y) {// x represente les lignes, y les colonnes
    HANDLE affiche = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD pos ={y,x};
    SetConsoleCursorPosition(affiche,pos);

}

int testDoublonProd(char nom[30]){
int s=0,i;
    for(i=0;i<nbre_Produits;i++){
        if(strcasecmp(prod[i].nom_produit,nom)==0){
            s=1;
        }
        if(s==1){
            printf("Ce produit existe deja\n");
        }
        return s;
    }
}

int genererNumeroProduit() {
    static int numStock= 0;
    return ++numStock;
}


int testNIF(char nif[11]) {
    if (strlen(nif) != 10) {
        printf("Erreur: Le NIF doit etre compose de 10 chiffres.\n");
        return 0;  // NIF invalide
    }

    for (int i = 0; i < 10; i++) {
        if (nif[i] < '0' || nif[i] > '9') {
            printf("Erreur: Le NIF doit etre compose uniquement de chiffres.\n");
            return 0;
        }
    }

    return 1;
}

int testChampVide(char vide[50]){
int z=0;
if(strcasecmp(vide,"")==0){
    z=1;
    printf("Le champ ne doit pas etre vide\n");
}
return z;
}

int testNumTel(char numTel[9]) {
    int x = 0;

    // Verifie que la chaine n'est pas vide
    if (strlen(numTel) == 0) {
        printf("Erreur: Le numero de telephone ne peut pas etre vide.\n");
        return 1;
    }

    // Verifie que la longueur du numero est bien de 8 caractres
    if (strlen(numTel) != 8) {
        printf("Erreur: Le numero de telephone doit comporter exactement 8 chiffres.\n");
        return 1;
    }

    // Verifie que tous les caracteres sont des chiffres
    for (int i = 0; i < 8; i++) {
        if (numTel[i] < '0' || numTel[i] > '9') {
            printf("Erreur: Le numero de telephone doit contenir uniquement des chiffres.\n");
            return 1;
        }
    }

    return x;
}

int testNumTelempDouble(char champ[15]) {
    int t=0,i;
    for (i=0; i < nbre_Employes; i++) {
        if (strcasecmp(emp[i].tel_employe, champ) == 0) {
            t=1;
        }
    }
    if(t==1){
        printf("Erreur: Ce numero de telephone est deja enregistre.\n");
    }

    return t;
}

int testNumTelcliDouble(char champ[15]) {
int s=0,j;
    for (j=0; j < nbre_Clients; j++) {
        if (strcasecmp(cl[j].tel_client, champ) == 0) {
            s=1;
        }
    }
    if(s==1){
        printf("Erreur: Ce numero de telephone est deja enregistre.\n");
    }
    return s;
}

int testNIFempDouble(char champ[15])
{
    int t=0,i;
    for (i=0; i < nbre_Employes; i++) {
        if (strcasecmp(emp[i].nif_employe, champ) == 0) {
            t=1;
        }
    }

    if(t==1){
        printf("Erreur: Ce NIF est deja enregistre.\n");
    }
    return t;
}

int testNIFclDouble(char champ[15])
{
    int s=0, j;
    for (j=0; j < nbre_Clients; j++) {
        if (strcasecmp(cl[j].nif, champ) == 0) {
            s=1;
        }
    }

    if(s==1){
        printf("Erreur: Ce NIF est deja enregistre.\n");
    }
    return s;
}



//Fonction menu gestion personnel
int menuGestionEmployes()
{
    int choix=0;
    system("cls");
		printf("_____Gestion du personnel administratif_____ \n");
		printf("============================================\n");
		printf("[1] Enregister les employes\n");
		printf("[2] Lister les employes \n");
		printf("[3] Rechercher un employe \n");
		printf("[4] Modifier une information liee a un employe \n");
		printf("[5] Augmentation de salaire \n");
		printf("[6] Revoquer un employe \n");
		printf("[7] Retourner au menu principal \n");
		printf("Faites votre choix: ");
		scanf("%d", &choix);
		return choix;
}

//Fonction du gestion personnel administratif
void Gestion_du_perso() {


	int choix=0;
	do
	{
	    choix=menuGestionEmployes();

		switch (choix) {
			case 1:
				Enregistrer_employe();
				break;
			case 2:
				Lister_employe();
				break;
            case 3:
				Rechercher_employe();
				break;
			case 4:
				Modifier_employe();
				break;
			case 5:
				Augmentation_salaire();
				break;
			case 6:
                 Revoquer_employe();
				break;
			case 7:
				MenuPrincipal();
			default:
				printf("Veuiller choisir entre 1 et 7: ");
		}

	} while(choix!=7);
}

// Sous fonction
//__________________________
void Enregistrer_employe() {
	system("cls");
    int n= 0;
    int reponse=0,i=nbre_Employes;
    do{
            getchar();

    do {
        printf("Entrez le NIF de l'employe: ");
        gets(emp[i].nif_employe);
    } while (testNIF(emp[i].nif_employe)==0 || testNIFempDouble(emp[i].nif_employe)==1 || testNIFclDouble(emp[i].nif_employe)==1);

    do{
        printf("Entrez le nom:");
        gets(emp[i].nom_employe);
    }while(testChampVide(emp[i].nom_employe)==1);

    do{
        printf("Entez le prenom:");
        gets(emp[i].prenom_employe);
    }while(testChampVide(emp[i].prenom_employe)==1);



    do{
    printf("Entrez l'adresse : ");
    gets(emp[i].adresse_employe);
    emp[i].adresse_employe[strcspn(emp[i].adresse_employe, "\n")] = '\0';

    }while(testChampVide(emp[i].adresse_employe)==1);

    do {
        printf("Entrez le numero de telephone: ");
        gets(emp[i].tel_employe);

    } while (testNumTelempDouble(emp[i].tel_employe)==1 || testNumTelcliDouble(emp[i].tel_employe)==1 || testNumTel(emp[i].tel_employe)==1);


    do {
        printf("Entrez le salaire : ");
        scanf("%lf", &emp[i].salaire);
    } while (emp[i].salaire <= 0);

    printf("L'employe a ete enregistre avec succes!\n");
    printf("\n\nVoulez vous enregistrer un autre employe(1=oui, 0=non)?\n");
    scanf("%d",&reponse);
    i++;
    nbre_Employes++;
    if(reponse==1){
        system("cls");
    }
}
while(reponse==1);
}

void Lister_employe() {
	 system("cls");
    int i,n=2;
    gotoxy(1,10);
    printf("NIF");
    gotoxy(1,25);
    printf("Nom");
    gotoxy(1,40);
    printf("Prenom");
    gotoxy(1,55);
    printf("Telephone");
    gotoxy(1,70);
    printf("Adresse");
    gotoxy(1,85);
    printf("Salaire");
    for(i=0;i<nbre_Employes;i++){
        gotoxy(n+i,10);
        printf("%s",emp[i].nif_employe);
        gotoxy(n+i,25);
        printf("%s",emp[i].nom_employe);
        gotoxy(n+i,40);
        printf("%s",emp[i].prenom_employe);
        gotoxy(n+i,55);
        printf("%s",emp[i].tel_employe);
        gotoxy(n+i,70);
        printf("%s",emp[i].adresse_employe);
        gotoxy(n+i,85);
        printf("%.3f\n",emp[i].salaire);
    }
    system("pause");
}

void Rechercher_employe() {
	 int pos=-1, n=0,i;
    char nif[10];
    system("cls");
    getchar();

    printf("Entrez le NIF de l'employe a rechercher: ");
    gets(nif);

    for (int i = 0; i < nbre_Employes; i++) {
        if (strcasecmp(emp[i].nif_employe, nif) == 0) {
            pos=i;
            n=1;
        }
        } system("cls");
        if(n==1){
            gotoxy(1,10);
            printf("NIF");
            gotoxy(1,25);
            printf("Nom");
            gotoxy(1,40);
            printf("Prenom");
            gotoxy(1,55);
            printf("Telephone");
            gotoxy(1,70);
            printf("Adresse");

            gotoxy(2,10);
            printf("%s",emp[pos].nif_employe);
            gotoxy(2,25);
            printf("%s",emp[pos].nom_employe);
            gotoxy(2,40);
            printf("%s",emp[pos].prenom_employe);
            gotoxy(2,55);
            printf("%s",emp[pos].tel_employe);
            gotoxy(2,70);
            printf("%s\n",emp[pos].adresse_employe);
            }
            else{
        printf("L'employe avec le NIF %s n'a pas ete trouve.\n", nif);
    }
    system("pause");
}

void Modifier_employe() {
	 int pos=-1,n=0,i,nn;
    char Nif[11],Nom[40],Prenom[30],tel[15];
    double Nsalaire;
    system("cls");
    getchar();

    printf("Entrer le NIF de l'employe a modifier: ");
    gets(Nif);
    for(i=0;i<nbre_Employes;i++){
        if(strcasecmp(emp[i].nif_employe,Nif)==0){
            pos=i;
            n=1;
        }
    }
    system("cls");
    if(n==1){
        do{
            gotoxy(1,5);
            printf("Choisissez l'information que vous voulez modifier \n");
            gotoxy(2,10);
            printf("1. Nom\n");
            gotoxy(3,10);
            printf("2. Prenom\n");
            gotoxy(4,10);
            printf("3. Telephone\n");
            gotoxy(5,10);
            printf("4. Salaire\n");
            gotoxy(6,10);
            printf("5. Retour au menu Gestion Employe\n");
            gotoxy(7,10);
            printf("Faites votre choix: ");
            scanf("%d",&nn);
            getchar();
            system("cls");
                switch(nn){
                case 1: {
                do{
                    printf("Entrez le nouveau nom\n");
                    gets(Nom);
                }while(testChampVide(Nom)==1);
                strcpy(emp[pos].nom_employe,Nom);
                system("cls");
                break;
                }
                case 2: {
                do{
                    printf("Entrez le nouveau prenom\n");
                    gets(Prenom);
                }while(testChampVide(Prenom)==1);
                strcpy(emp[pos].prenom_employe,Prenom);
                system("cls");
                break;
                }
                case 3: {
                do{
                    printf("Entrez le nouveau numero de telephone: ");
                    gets(tel);
                }while(testNumTel(tel)==1 || testNumTelempDouble(tel)==1 ||testNumTelempDouble(tel)==1);
                strcpy(emp[pos].tel_employe,tel);
                }
                case 4: {
                do{
                    printf("Entrez le nouveau salaire: ");
                    scanf("%lf",&Nsalaire);
                }while(Nsalaire<=0);
                emp[pos].salaire=Nsalaire;
                system("cls");
                break;
                }
                case 5: {
                    Gestion_du_perso();
                    system("cls");
                    break;
                }
                default:{
                printf("Mauvais choix !!!\n");
                system("cls");
                break;
                }
                }
        }while(nn>=1 || nn<=5);
    }
        else{
            printf("Ce NIF n'existe pas \n");
        }
        system("pause");
}

void Augmentation_salaire() {
	system("cls");
	char Nif[10];
    getchar();
    int pos=-1,i,n;
     printf("Entrer le NIF de l'employe a modifier: ");
    gets(Nif);
    for(i=0;i<nbre_Employes;i++){
        if(strcasecmp(emp[i].nif_employe,Nif)==0){
            pos=i;
            n=1;
        }
    }
        if (emp[pos].salaire < 25000) {
            emp[pos].salaire=emp[pos].salaire + (emp[pos].salaire*0.10);
        } else {
            emp[pos].salaire=emp[pos].salaire + (emp[pos].salaire*0.15);
        }
        printf("Le salaire de %s a ete augmente. Nouveau salaire: %lf\n", emp[pos].nom_employe, emp[i].salaire);

    system("pause");
}

void Revoquer_employe() {
	int pos=-1,n=0,i;
    char nif[10];
    system("cls");
    getchar();

    printf("Entrez le NIF de l'employe a revoquer: ");
    gets(nif);


    for (i = 0; i < nbre_Employes; i++) {
        if (strcmp(emp[i].nif_employe, nif) == 0) {
                pos=i;
                n=1;
        }
    } system("cls");
        if(n==1){
            strcpy(emp[pos].nif_employe,"");
            strcpy(emp[pos].nom_employe,"");
            strcpy(emp[pos].prenom_employe,"");
            strcpy(emp[pos].tel_employe,"");
            strcpy(emp[pos].adresse_employe,"");
            emp[pos].salaire=0;
            printf("L'employe est revoque\n");
        }
        else {
            printf("L'employe avec le NIF %s n'a pas ete trouve\n",nif);
        }
        system("pause");
}
//____________________________
//____________________________

//Fonction menu du Gestion
int menuGestionProduits()
{
    int choix=0;
    system("cls");
		printf("_____Gestion des produits_____\n");
		printf("==============================\n");
		printf("[1] Enregistrer un produit\n");
		printf("[2] Lister les produits par categorie\n");
		printf("[3] Rechercher un produits \n");
		printf("[4] Augmenter le nombre de caisse\n");
		printf("[5] Supprimer un produit\n");
		printf("[6] Retourner au menu principal\n");
		printf("Faites votre choix: ");
		scanf("%d", &choix);
		return choix;
}

//Fonction des produits
void Gestion_des_produits() {

	int choix=0;
	do
	{
		choix=menuGestionProduits();

		switch (choix) {
		case 1:
			Enregistrer_produit();
			break;
		case 2:
			Lister_produit();
			break;
		case 3:
			Rechercher_produit();
			break;
		case 4:
			Augmenter_caisse();
			break;
		case 5:
			Supprimer_produit();
			break;
		case 6:
			MenuPrincipal();
		default:
			printf("Veuillez choisir entre 1 et 6: ");
		}
	} while(choix!=6);
}

//Sous fontions
//______________________________
void Enregistrer_produit() {

	 int reponse=0,i=nbre_Produits;
	 int ch,ch2,ch3;

    do{
    system("cls");
    printf("Choisisse la categorie de boisson a enregistrer\n");
    printf("1.Alcoolise\n");
    printf("2.Gazeux\n");
    scanf("%d",&ch);
     switch(ch){
 case 1:
        strcpy(prod[i].categorie,"Alcoolises");
        printf("Choisisse le produit a enregistrer\n");
        printf("1.Prestige\n");
        printf("2.Kinanm\n");
        printf("3.Guiness\n");
        scanf("%d",&ch2);
          switch(ch2){
            case 1:
                strcpy(prod[i].nom_produit, "Prestige");
                break;
            case 2:
                strcpy(prod[i].nom_produit, "Kinanm");
                break;
            case 3:
                strcpy(prod[i].nom_produit, "Guiness");
                break;
            default:
            printf("veuille choisir entre 1 a 3.");
            break;
        }
break;
 case 2:
      strcpy(prod[i].categorie,"Gazeux");
       printf("Choisisse le produit a enregistrer\n");
        printf("1.Toro\n");
        printf("2.Fanta\n");
        printf("3.Coca\n");
        printf("4.Cola\n");
        printf("5.Pepsi\n");
        scanf("%d", &ch3);
          switch(ch3){
        case 1:
            strcpy(prod[i].nom_produit, "Toro");
            break;
        case 2:
            strcpy(prod[i].nom_produit, "Fanta");
            break;
        case 3:
            strcpy(prod[i].nom_produit, "Coca");
            break;
        case 4:
            strcpy(prod[i].nom_produit, "Cola");
            break;
        case 5:
            strcpy(prod[i].nom_produit, "Pepsi");
            break;
        default:
         printf("veuille choisir entre 1 a 5.\n");
          }
     }



    do {

        printf("Entrez le nombre de caisses: ");
        scanf("%d", &prod[i].nb_caisse);
        getchar();
    } while (prod[i].nb_caisse <=0);


    do {
        printf("Entrez le prix du produit: ");
        scanf("%lf", &prod[i].prix);
        getchar();
    } while (prod[i].prix <= 0);

    prod[i].numStock= nbre_Produits +1;



    printf("Le produit %s a ete enregistre avec succes!\n\n", prod[i].nom_produit);

    printf("\nvoulez vous enregistrer un autre produit? (1=oui, 0=non)? \n");
    scanf("%d",&reponse);
    i++;
    nbre_Produits++;
    if(reponse==1){
             system("cls");
    }
}while(reponse==1);
    system("pause");
}

void Lister_produit() {
	 system("cls");
    int i,n=2;
    gotoxy(1,10);
    printf("Numero");
    gotoxy(1,25);
    printf("Nom");
    gotoxy(1,40);
    printf("Categorie");
    gotoxy(1,55);
    printf("Nb de caisse");
    gotoxy(1,70);
    printf("prix\n");

    for(i=0;i<nbre_Produits;i++){
        gotoxy(n+i,10);
        printf("%d",prod[i].numStock);
        gotoxy(n+i,25);
        printf("%s",prod[i].nom_produit);
        gotoxy(n+i,40);
        printf("%s",prod[i].categorie);
        gotoxy(n+i,55);
        printf("%d",prod[i].nb_caisse);
        gotoxy(n+i,70);
        printf("%.3lf\n",prod[i].prix);
    }
   system("pause");

}

void Rechercher_produit() {
	int pos=-1,n=0,i;
char nom[50];
system("cls");
getchar();
printf("Entrer le nom du Produit a rechercher: ");
gets(nom);
for(i=0; i<nbre_Produits; i++){
    if(strcasecmp(prod[i].nom_produit,nom)==0){
        pos=i; //on reccup�re la position du produit
        n=1;
    }
}
system("cls");
if(n==1){
gotoxy(1,10);
printf("Numero Stock");
gotoxy(1,25);
printf("Nom");
gotoxy(1,40);
printf("Categorie");
gotoxy(1,55);
printf("Nb Caisse");
gotoxy(1,70);
printf("Prix");

 gotoxy(2,10);
printf("%d",prod[pos].numStock);
gotoxy(2,25);
printf("%s",prod[pos].nom_produit);
gotoxy(2,40);
printf("%s",prod[pos].categorie);
gotoxy(2,55);
printf("%d",prod[pos].nb_caisse);
gotoxy(2,70);
printf("%.3lf",prod[pos].prix);
system("pause");
}
else {
    printf("Ce nom Produit n'existe pas\n");
}
system("pause");
}

void Augmenter_caisse() {
	int numStock, nb_Caisse;
    int n= 0;

    printf("Entrez le numero de stock du produit: ");
    scanf("%d", &numStock);
    getchar();

    printf("Entrez le nombre de caisses a ajouter: ");
    scanf("%d", &nb_Caisse);
    getchar();

    for (int i = 0; i < nbre_Produits; i++) {
        if (prod[i].numStock == numStock) {
            prod[i].nb_caisse += nb_Caisse;
            printf("Le nombre de caisses pour le produit '%s' a été augmenté de %d. Nouveau nombre de caisses: %d\n",
                   prod[i].nom_produit, nb_Caisse, prod[i].nb_caisse);
           n= 1;
            break;
        }
    }

    if (!n) {
        printf("Ce produit est introuvable \n", numStock);
    }
}

void Supprimer_produit() {
     int numStock;
    int n= 0;

    printf("Entrez le numero de stock du produit a supprimer: ");
    scanf("%d", &numStock);
    getchar();

    for (int i = 0; i < nbre_Produits; i++) {
        if (prod[i].numStock == numStock) {

            for (int j = i; j < nbre_Produits - 1; j++) {
                prod[j] = prod[j + 1];
            }
            nbre_Produits--;
            printf("Le produit avec numero de stock %d a ete supprime.\n", numStock);
            n= 1;
            break;
        }
    }

    if (!n) {
        printf("Ce produit est introuvable\n", numStock);
    }
}
//__________________________________
//__________________________________



//Fonction Menu du Gestion client
int menuGestionClients()
{
    int choix=0;
	system("cls");
	printf("_____Gestion des clients_____\n");
	printf("=============================\n");
	printf("[1] Enregistrer un client\n");
	printf("[2] Lister les clients\n");
	printf("[3] Rechercher un client\n");
	printf("[4] Modifier les infos d'un client\n");
	printf("[5] Supprimer un client\n");
	printf("[6] Retourner au menu principal\n");
	printf("Faites votre choix: ");
	scanf("%d", &choix);
	return choix;
}

//Fonction du gestion des clients
void Gestion_des_clients() {
    int choix=0;

	do
	{
	    choix=menuGestionClients();
		switch (choix) {
			case 1:
				Enregistrer_client();
				break;
			case 2:
				Lister_client();
				break;
			case 3:
				Rechercher_client();
				break;
			case 4:
				Modifier_client();
				break;
			case 5:
				Supprimer_client();
				break;
			case 6:
				MenuPrincipal();
			default:
				printf("Veuillez choisir entre 1 et 6: ");
		}
	} while(choix!=6);
}

//Sous fonction
//_____________________________________
void Enregistrer_client() {
	system("cls");
    int n= 0;
    int reponse=0,i=nbre_Clients;
    do{
            getchar();

    do {
        printf("Entrez Le NIF du client: \n");
        gets(cl[i].nif);
    } while (testNIF(cl[i].nif)==0 || testNIFempDouble(cl[i].nif)==1 || testNIFclDouble(cl[i].nif)==1);

    do{
        printf("Entrez le nom: ");
        gets(cl[i].nom_client);
    }while(testChampVide(cl[i].nom_client)==1);

    do{
        printf("Entez le prenom: ");
        gets(cl[i].prenom_client);
    }while(testChampVide(cl[i].prenom_client)==1);



    do{
    printf("Entrez l'adresse : ");
    gets(cl[i].adresse_client);
    }while(testChampVide(cl[i].adresse_client)==1);

    do {
        printf("Entrez le numero de telephone: ");
        gets(cl[i].tel_client);
    } while (testNumTel(cl[i].tel_client)==1 || testNumTelcliDouble(cl[i].tel_client)==1 || testNumTelempDouble(cl[i].tel_client));

    printf("\n\nLe client a ete enregistre avec succes!\n");
    printf("\nVoulez vous enregistrer un autre Client (1=oui, 0=non)?\n");
    scanf("%d",&reponse);
    i++;
    nbre_Clients++;
    if(reponse==1){
        system("cls");
    }
}while(reponse==1);
}

void Lister_client() {
	 system("cls");
    int i,n=2;
    gotoxy(1,10);
    printf("NIF");
    gotoxy(1,25);
    printf("Nom");
    gotoxy(1,40);
    printf("Prenom");
    gotoxy(1,55);
    printf("Telephone");
    gotoxy(1,70);
    printf("Adresse");
    for(i=0;i<nbre_Clients;i++){
        gotoxy(n+i,10);
        printf("%s",cl[i].nif);
        gotoxy(n+i,25);
        printf("%s",cl[i].nom_client);
        gotoxy(n+i,40);
        printf("%s",cl[i].prenom_client);
        gotoxy(n+i,55);
        printf("%s",cl[i].tel_client);
        gotoxy(n+i,70);
        printf("%s",cl[i].adresse_client);
    }
    system("pause");
}

void Rechercher_client() {
	 int pos=-1, n=0,i;
    char nif[10];
    system("cls");
    getchar();

    printf("Entrez le NIF du client a rechercher: ");
    gets(nif);

    for (int i = 0; i < nbre_Clients; i++) {
        if (strcasecmp(cl[i].nif, nif) == 0) {
            pos=i;
            n=1;
        }
        } system("cls");
        if(n==1){
            gotoxy(1,10);
            printf("NIF");
            gotoxy(1,25);
            printf("Nom");
            gotoxy(1,40);
            printf("Prenom");
            gotoxy(1,55);
            printf("Telephone");
            gotoxy(1,70);
            printf("Adresse");

            gotoxy(2,10);
            printf("%s",cl[pos].nif);
            gotoxy(2,25);
            printf("%s",cl[pos].nom_client);
            gotoxy(2,40);
            printf("%s",cl[pos].prenom_client);
            gotoxy(2,55);
            printf("%s",cl[pos].tel_client);
            gotoxy(2,70);
            printf("%s\n",cl[pos].adresse_client);
            }
            else{
        printf("Le client avec le NIF %s n'a pas ete trouve.\n", nif);
    }
    system("pause");
}

void Modifier_client() {
	 int pos=-1,n=0,i,nn;
    char Nif[11],Nom[40],Prenom[30],tel[15],Adr[30];
    system("cls");
    getchar();

    printf("Entrer le NIF du client a modifier\n");
    gets(Nif);
    for(i=0;i<nbre_Clients;i++){
        if(strcasecmp(cl[i].nif,Nif)==0){
            pos=i;
            n=1;
        }
    }
    system("cls");
    if(n==1){
        do{
            gotoxy(1,5);
            printf("Choisissez l'information que vous voulez modifier \n");
            gotoxy(2,10);
            printf("1. Nom\n");
            gotoxy(3,10);
            printf("2. Prenom\n");
            gotoxy(4,10);
            printf("3. Telephone\n");
            gotoxy(5,10);
            printf("4. Adresse\n");
            gotoxy(6,10);
            printf("5. Retour au menu Gestion Employe\n");
            gotoxy(7,10);
            printf("Faites votre choix !!!\n");
            scanf("%d",&nn);
            getchar();
            system("cls");
                switch(nn){
                case 1: {
                do{
                    printf("Entrez le nouveau nom\n");
                    gets(Nom);
                }while(testChampVide(Nom)==1);
                strcpy(cl[pos].nom_client,Nom);
                system("cls");
                break;
                }
                case 2: {
                do{
                    printf("Entrez le nouveau prenom\n");
                    gets(Prenom);
                }while(testChampVide(Prenom)==1);
                strcpy(cl[pos].prenom_client,Prenom);
                system("cls");
                break;
                }
                case 3: {
                do{
                    printf("Entrez le nouveau numero de telephone\n");
                    gets(tel);
                }while(testNumTel(tel)==1 || testNumTelempDouble(tel)==1 || testNumTelcliDouble(tel)==1);
                strcpy(cl[pos].tel_client,tel);
                break;
                }
                case 4: {
                do{
                    printf("Entrez la nouvelle adresse\n");
                    gets(Adr);
                }while(testChampVide(Adr)==1);
                strcpy(cl[pos].adresse_client,tel);
                break;
                }
                case 5: {
                    Gestion_des_clients();
                    system("cls");
                    break;
                }
                default:{
                printf("Mauvais choix !!!\n");
                system("cls");
                break;
                }
                }
        }while(nn>=1 || nn<=5);
    }
        else{
            printf("Ce NIF n'existe pas \n");
        }
        system("pause");
}

void Supprimer_client() {
	int pos=-1,n=0,i;
    char nif[10];
    system("cls");
    getchar();

    printf("Entrez le NIF du a revoquer: ");
    gets(nif);


    for (i = 0; i < nbre_Clients; i++) {
        if (strcmp(cl[i].nif, nif) == 0) {
                pos=i;
                n=1;
        }
    } system("cls");
        if(n==1){
            strcpy(cl[pos].nif,"");
            strcpy(cl[pos].nom_client,"");
            strcpy(cl[pos].prenom_client,"");
            strcpy(cl[pos].tel_client,"");
            strcpy(cl[pos].adresse_client,"");
            printf("Le client est suprime\n");
        }
        else {
            printf("Le client avec le NIF %s n'a pas ete trouve\n",nif);
        }
        system("pause");
}
//___________________________________
//___________________________________


//Fonction menu gestion de ventes
int menuGestionVentes()
{
    int choix=0;
	system("cls");
	printf("_____Gestion des ventes_____\n");
	printf("============================\n");
	printf("[1] Effectuer une vente\n");
	printf("[2] Lister les ventes\n");
	printf("[3] Annuler une vente\n");
	printf("[4] Retourner au menu principal\n");
	printf("Faites votre choix: ");
	scanf("%d", &choix);
	return choix;
}

//Fonction du gestion des ventes
void Gestion_des_ventes() {
    int choix=0;
	do
	{
		choix=menuGestionVentes();

		switch (choix) {
		case 1:
			Effectuer_vente();
			break;
		case 2:
			Lister_vente();
			break;
		case 3:
			Annuler_vente();
			break;
		case 4:
			MenuPrincipal();
        default:
			printf("Veuillez choisir entre 1 et 4: ");
		}
	} while(choix!=4);
}
//Sous fonctions
//____________________________________
void Effectuer_vente()
{
    int quantite,i=nbre_Ventes,j,l,pos1=-1,pos2=-1,n=0,nn=0;
     char numrt[15],nomrt[50];
     int ch, ch2, ch3;





        system("cls");
        printf("Voici les categories\n");
        printf("1.Alcoolise\n");
        printf("2.Gazeux\n");
        printf("Faites votre choix:");
        scanf("%d",&ch);
        switch(ch){
            case 1:
                strcpy(prod[i].categorie,"Alcoolises");
                printf("Voici les produits alcoolises\n");
                printf("1.Prestige\n");
                printf("2.Kinanm\n");
                printf("3.Guiness\n");
                printf("Veuillez choisir:");
                scanf("%d",&ch2);
                switch(ch2){
                    case 1:
                        strcpy(nomrt, "Prestige");
                    break;
                    case 2:
                    strcpy(nomrt, "Kinanm");
                    break;
                case 3:
                    strcpy(nomrt, "Guiness");
                break;
                default:
                    printf("veuille choisir entre 1 a 3.");
                    break;
                }
            break;
            case 2:
                strcpy(prod[i].categorie,"Gazeux");
                printf("voici les produits gazeux\n");
                printf("1.Toro\n");
                printf("2.Fanta\n");
                printf("3.Coca\n");
                printf("4.Cola\n");
                printf("5.Pepsi\n");
                printf("Veuillez choisir:");
                scanf("%d", &ch3);
                switch(ch3){
                    case 1:
                        strcpy(nomrt, "Toro");
                    break;
                    case 2:
                        strcpy(nomrt, "Fanta");
                    break;
                    case 3:
                        strcpy(nomrt, "Coca");
                    break;
                    case 4:
                        strcpy(nomrt, "Cola");
                    break;
                    case 5:
                        strcpy(nomrt, "Pepsi");
                    break;
                    default:
                        printf("veuille choisir entre 1 a 5.");
                }

            break;
            default:
                printf("Veuillez choisir entre 1 et 2");


     }



    for(l=0; l<nbre_Produits; l++){
        if(strcasecmp(prod[i].nom_produit,nomrt)==0){
            pos1=l;
            n=1;
        }
    }

    if(n==1){

        do {
        printf("Entrer le numero du telephone du client:");
        gets(numrt);
        }while(testChampVide(numrt));

        for(j=0; j<nbre_Clients; j++){
            if(strcasecmp(cl[j].tel_client,numrt)==0){
                pos2=j;
                nn=1;
            }
        }
        if(nn==1){
            do{
                printf("Entrer la quantite de caisse du produit a commander\n");
                scanf("%d",&quantite);
            }
            while(quantite<=0);

            ventes[i].montantAchat=prod[pos1].prix*quantite;
            prod[pos1].nb_caisse-=quantite;
            ventes[i].numProduit=prod[pos1].numStock;
            strcpy(ventes[i].numClient,cl[pos2].tel_client);
            strcpy(ventes[i].nomCl, cl[pos2].nom_client);
            strcpy(ventes[i].nomPr,prod[pos1].nom_produit);
            ventes[i].quantite=quantite;
            ventes[i].numVente =nbre_Ventes+1;

            i++;
            nbre_Ventes++;
            printf("Le vente a ete effectuee\n");


        }
        else{
        printf("Ce client n'est pas encore enregistre\n");
        }

    }
    else{
    printf("Ce produit n'existe pas\n");
    }

    system("pause");

}

void Lister_vente() {
	 system("cls");
    int i,n=3;
    gotoxy(1,10);
    printf("Numero vente");
    gotoxy(1,25);
    printf("Numero Produit");
    gotoxy(1,40);
    printf("Numero Client");
    gotoxy(1,55);
    printf("Nom Client");
    gotoxy(1,70);
    printf("Nom Produit");
    gotoxy(1,85);
    printf("Quantite");
    gotoxy(1,95);
    printf("Montant Achat\n");

    for (i=0;i<nbre_Ventes;i++){
        gotoxy(n+i,10);
        printf("%d",ventes[i].numVente);
        gotoxy(n+i,25);
        printf("%d",ventes[i].numProduit);
        gotoxy(n+i,40);
        printf("%d",ventes[i].numClient);
        gotoxy(n+i,55);
        printf("%s",ventes[i].nomCl);
        gotoxy(n+i,70);
        printf("%s",ventes[i].nomPr);
        gotoxy(n+i,85);
        printf("%d",ventes[i].quantite);
        gotoxy(n+i,95);
        printf("%lf\n",ventes[i].montantAchat);
    }

    system("pause");
}

void Annuler_vente() {
	int pos=-1,pos1=-1,n=0,i,j,num;
    system("cls");
    printf("Entrer le numero de la vente a rechercher\n");
    scanf("%d",&num);
    for(i=0; i<nbre_Ventes; i++){
        if(ventes[i].numVente==num){
            pos=i;
            n=1;
        }
    }
    system("cls");
    if(n==1){
      for(j=0; j<nbre_Produits; j++){
        if(strcasecmp(prod[j].nom_produit,ventes[pos].nomPr)==0){
            pos1=j;
        }
      }

        prod[pos1].nb_caisse+=ventes[pos].quantite;
        ventes[pos].montantAchat=0;
        ventes[pos].numProduit=0;
        strcpy(ventes[pos].numClient, "");
        strcpy(ventes[pos].nomCl,"");
        strcpy(ventes[pos].nomPr,"");
        ventes[pos].quantite=0;
        ventes[pos].numVente=0;
    }
    else{
        printf("Numero de vente introuvable\n");
    }
    system("pause");
}

void Rechercher_vente(){
    int pos=-1,n=0,i,numvente;
    system("cls");
    printf("Entrer le numero de la vente.\n");
    scanf("%d",&numvente);

    for(i=0;i<nbre_Ventes;i++){
        if(ventes[i].numVente==numvente){
                pos=i;
                n=1;
        }
    }
    system("cls");
    if(n==1){
            gotoxy(1,10);
           printf("Numero_vente");
           gotoxy(1,25);
           printf("Numero_Produit");
           gotoxy(1,40);
           printf("Numero Client");
           gotoxy(1,55);
           printf("Nom Client");
           gotoxy(1,70);
           printf("Nom_Produit");
           gotoxy(1,85);
            printf("Quantite");
           gotoxy(1,95);
           printf("Montant Achat");

           gotoxy(2,10);
           printf("%d",ventes[pos].numVente);
           gotoxy(2,25);
           printf("%d",ventes[pos].numProduit);
           gotoxy(2,40);
           printf("%d",ventes[pos].numClient);
           gotoxy(2,55);
           printf("%s",ventes[pos].nomCl);
           gotoxy(2,70);
           printf("%s",ventes[pos].nomPr);
           gotoxy(2,85);
           printf("%d",ventes[pos].quantite);
           gotoxy(2,95);
           printf("%lf\n",ventes[pos].montantAchat);
    }
    system("pause");
}

void Modifier_vente(){
    int pos=-1,n=0,i,nn,numvente;
    int QUANT,MONT,NUMP;
    char NOM[30],NOMPR[30], NUMC[9];
    system("cls");
    getchar();

    printf("Entrer le numero de la vente a modifier\n");
    scanf("%d", &numvente);
    for(i=0;i<nbre_Ventes;i++){
        if(ventes[i].numVente==numvente){
            pos=i;
            n=1;
        }
    }
    system("cls");
    if(n==1){
        do{
            gotoxy(1,5);
            printf("Choisissez l'information que vous voulez modifier \n");
            gotoxy(2,10);
            printf("1. Numero du produit\n");
            gotoxy(3,10);
            printf("2. Numero du client\n");
            gotoxy(4,10);
            printf("3. Nom du client\n");
            gotoxy(5,10);
            printf("4. Nom du produit \n");
            gotoxy(6,10);
            printf("5. Quantite\n");
            gotoxy(7,10);
            printf("6. Montant Achat !!!\n");
            scanf("%d",&nn);
            getchar();
            system("cls");
                switch(nn){
                case 1: {
                do{
                    printf("Entrez le nouveau numero du produit\n");
                    scanf("%d", &NUMP);
                }while(NUMP<=0);
                ventes[pos].numProduit=NUMP;
                system("cls");
                break;
                }
                case 2: {
                do{
                    printf("Entrez le nouveau numero du client\n");
                    gets(NUMC);
                }while(testNumTel(NUMC)==1 || testNumTelcliDouble(NUMC)==1 || testNumTelempDouble(NUMC)==1);
                strcpy(ventes[pos].numClient, NUMC);
                system("cls");
                break;
                }
                case 3: {
                do{
                    printf("Entrez le nouveau nom du client\n");
                    gets(NOM);
                }while(testChampVide(NOM)==1);
                strcpy(ventes[pos].nomCl,NOM);
                break;
                }
                case 4: {
                do{
                    printf("Entrez le nouveau nom du produit\n");
                    gets(NOMPR);
                }while(testChampVide(NOMPR)==1);
                strcpy(ventes[pos].nomPr,NOMPR);
                break;
                }
                 case 5: {
                do{
                    printf("Entrez la nouvelle quantite\n");
                    scanf("%d",&QUANT);
                }while(QUANT<=0);
                ventes[pos].quantite=QUANT;
                system("cls");
                break;
                 }
                 case 6: {
                do{
                    printf("Entrez le nouveau montant d'achat\n");
                    scanf("%d",&MONT);
                }while(MONT<=0);
                ventes[pos].montantAchat=MONT;
                system("cls");
                break;
                 }
                case 7: {
                    Gestion_des_clients();
                    system("cls");
                    break;
                }
                default:{
                printf("Mauvais choix !!!\n");
                system("cls");
                break;
                }
                }
        }while(nn>=1 || nn<=7);
    }
     else{
            printf("Ce NIF n'existe pas \n");
        }
        system("pause");

        }

//____________________________________
//____________________________________



// Fonction Menu principal
void MenuPrincipal()
{

	int choix=0;
	do {
		system("cls");
		printf("-----Bienvenue sur Jorel Depot----- \n");
		printf("=================================== \n");
		printf("[1] Gestion du personnel administratif \n");
		printf("[2] Gestion des produits \n");
		printf("[3] Gestion des clients \n");
		printf("[4] Gestion des ventes \n");
		printf("[5] Pour quitter l'application \n");
		printf("Faites votre choix: ");


		//Lecture securisee du choix
		if(scanf("%d",&choix)!=1) {
			printf("Choix invalide, entrer un nombre: ");
			while(getchar() != '\n'); //Vider le tampon d'entre pour eviter unbufferoverflow
			choix=0;
			continue;
		}
		switch (choix) {
			case 1:
				Gestion_du_perso();
				break;
			case 2:
				Gestion_des_produits();
				break;
			case 3:
				Gestion_des_clients();
				break;
			case 4:
				Gestion_des_ventes();
				break;
			case 5:
				printf("\nMerci d'avoir utiliser Jorel depot, MERCI!!! \n");
				break;
			default:
				printf("Veuillez choisir entre 1 et 5: ");
			}

	} while(choix!=5);
}

//Fonction Main (Principale)
int main() {

	//Appel de la fonction principale
	MenuPrincipal();

	return 0;
}
